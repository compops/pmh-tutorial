# pmhtutorial 1.0.1
* Bug fixes related the the plots.
* Added the Markov chain trace to the variables
  retured from example3_sv, example4_sv and
  example5_sv.

# pmhtutorial 1.0.0
* Initial release.
